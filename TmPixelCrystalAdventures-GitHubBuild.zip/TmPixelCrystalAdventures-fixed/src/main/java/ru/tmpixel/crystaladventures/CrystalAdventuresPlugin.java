
package ru.tmpixel.crystaladventures;

import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.boss.*;
import org.bukkit.command.*;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.inventory.*;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

import java.io.*;
import java.net.URI;
import java.nio.file.*;
import java.security.MessageDigest;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public final class CrystalAdventuresPlugin extends JavaPlugin implements Listener, CommandExecutor, TabCompleter {
    private final Map<UUID, PlayerProgress> progress = new HashMap<>();
    private final Map<UUID, BossBar> bossBars = new HashMap<>();
    private final NamespacedKey itemKey = new NamespacedKey(this, "item_id");
    private BukkitTask autosaveTask;
    private BukkitTask eventTask;
    private boolean eventActive = false;
    private long eventEndsAt = 0L;
    private Location eventLocation;
    private int eventMobCount = 0;
    private final Random random = new Random();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        saveResource("messages.yml", false);
        getServer().getPluginManager().registerEvents(this, this);
        Objects.requireNonNull(getCommand("tca")).setExecutor(this);
        Objects.requireNonNull(getCommand("tca")).setTabCompleter(this);
        loadProgress();
        extractEmbeddedPack();
        long saveTicks = Math.max(20, getConfig().getLong("settings.autosave-seconds", 60) * 20);
        autosaveTask = getServer().getScheduler().runTaskTimerAsynchronously(this, this::saveProgressSafely, saveTicks, saveTicks);
        eventTask = getServer().getScheduler().runTaskTimer(this, this::tickEventSystem, 200L, 200L);
        getLogger().info("TmPixel Crystal Adventures enabled. Embedded resource pack is bundled in the JAR.");
    }

    @Override
    public void onDisable() {
        if (autosaveTask != null) autosaveTask.cancel();
        if (eventTask != null) eventTask.cancel();
        saveProgressSafely();
        for (BossBar bar : bossBars.values()) bar.removeAll();
        bossBars.clear();
    }

    private void extractEmbeddedPack() {
        try (InputStream in = getResource("resourcepack/resourcepack.zip")) {
            if (in == null) {
                getLogger().warning("Embedded resourcepack.zip not found. Run Gradle build.");
                return;
            }
            Path out = getDataFolder().toPath().resolve("resourcepack.zip");
            Files.createDirectories(out.getParent());
            Files.copy(in, out, StandardCopyOption.REPLACE_EXISTING);
            String sha1 = sha1(out);
            getLogger().info("Embedded resource pack extracted: " + out + " (SHA-1 " + sha1 + ")");
            String url = getConfig().getString("pack.public-url", "").trim();
            if (url.isBlank()) {
                getLogger().warning("Set pack.public-url to a publicly reachable direct URL to enable automatic client download.");
            } else {
                try { URI.create(url); } catch (Exception ex) {
                    getLogger().warning("pack.public-url is not a valid URI.");
                }
            }
        } catch (Exception ex) {
            getLogger().severe("Could not extract embedded resource pack: " + ex.getMessage());
        }
    }

    private String sha1(Path path) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-1");
        try (InputStream in = Files.newInputStream(path)) {
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) digest.update(buf, 0, n);
        }
        StringBuilder sb = new StringBuilder();
        for (byte b : digest.digest()) sb.append(String.format("%02x", b));
        return sb.toString();
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        progress.computeIfAbsent(p.getUniqueId(), id -> new PlayerProgress());
        String url = getConfig().getString("pack.public-url", "").trim();
        if (!url.isBlank()) {
            Bukkit.getScheduler().runTaskLater(this, () -> {
                if (!p.isOnline()) return;
                try {
                    p.setResourcePack(url, hexToBytesSafe(packHash()), getConfig().getString("pack.prompt-message", "Загрузи ресурс-пак TmPixel"), getConfig().getBoolean("pack.required", false));
                } catch (Exception ex) {
                    getLogger().warning("Could not send resource pack to " + p.getName() + ": " + ex.getMessage());
                }
            }, 40L);
        }
    }

    private byte[] hexToBytesSafe(String hash) {
        try {
            byte[] out = new byte[hash.length() / 2];
            for (int i = 0; i < out.length; i++) out[i] = (byte) Integer.parseInt(hash.substring(i * 2, i * 2 + 2), 16);
            return out;
        } catch (Exception ex) { return new byte[20]; }
    }

    private String packHash() {
        try { return sha1(getDataFolder().toPath().resolve("resourcepack.zip")); }
        catch (Exception ex) { return "0000000000000000000000000000000000000000"; }
    }

    @EventHandler(ignoreCancelled = true)
    public void onBlockBreak(BlockBreakEvent e) {
        Material type = e.getBlock().getType();
        if (!(type.name().endsWith("_ORE") || type == Material.DEEPSLATE || type == Material.STONE)) return;
        double chance = getConfig().getDouble("crystals.drop-chance", 0.08);
        if (random.nextDouble() > chance) return;
        Player p = e.getPlayer();
        ItemStack crystal = createItem("crystal_shard", 1);
        e.getBlock().getWorld().dropItemNaturally(e.getBlock().getLocation().add(.5, .5, .5), crystal);
        PlayerProgress pp = progress.computeIfAbsent(p.getUniqueId(), id -> new PlayerProgress());
        pp.crystalsFound++;
        pp.xp += 1;
        p.sendMessage(color("&b✦ &fТы нашёл &dКристаллический осколок&f! &7(Исследовательский опыт +1)"));
        p.playSound(p.getLocation(), Sound.BLOCK_AMETHYST_BLOCK_CHIME, .7f, 1.6f);
        p.spawnParticle(Particle.END_ROD, e.getBlock().getLocation().add(.5, .7, .5), 10, .25, .3, .25, .01);
    }

    private void tickEventSystem() {
        if (eventActive) {
            if (System.currentTimeMillis() >= eventEndsAt || eventMobCount <= 0) endEvent();
            else updateBossBars();
            return;
        }
        long min = getConfig().getLong("settings.event-min-interval-minutes", 45);
        long max = Math.max(min, getConfig().getLong("settings.event-max-interval-minutes", 90));
        // A simple random roll each check; avoids storing a separate timer.
        if (random.nextDouble() < 0.015) startEvent(null);
    }

    private void startEvent(Player initiator) {
        if (eventActive) {
            if (initiator != null) initiator.sendMessage(color("&cСобытие уже идёт."));
            return;
        }
        World world = chooseEventWorld(initiator);
        if (world == null) {
            if (initiator != null) initiator.sendMessage(color("&cНе найден мир для события. Проверь settings.event-worlds в config.yml."));
            return;
        }
        eventActive = true;
        eventEndsAt = System.currentTimeMillis() + getConfig().getLong("settings.event-duration-seconds", 300) * 1000L;
        int x = random.nextInt(81) - 40;
        int z = random.nextInt(81) - 40;
        Location origin = initiator != null ? initiator.getLocation() : world.getSpawnLocation();
        eventLocation = origin.clone().add(x, 0, z);
        eventLocation.setY(world.getHighestBlockYAt(eventLocation) + 1);
        eventMobCount = Math.min(12, getConfig().getInt("settings.max-event-mobs", 12));
        world.strikeLightningEffect(eventLocation);
        world.spawnParticle(Particle.PORTAL, eventLocation, 120, 2, 1, 2, .15);
        world.playSound(eventLocation, Sound.ENTITY_ENDER_DRAGON_GROWL, 1f, .8f);
        Bukkit.broadcastMessage(color("&5&lКРИСТАЛЛИЧЕСКИЙ РАЗЛОМ &7появился в мире &f" + world.getName() + "&7! Координаты: &d" +
                eventLocation.getBlockX() + ", " + eventLocation.getBlockY() + ", " + eventLocation.getBlockZ()));
        BossBar bar = Bukkit.createBossBar(color("&5Кристаллический разлом"), BarColor.PURPLE, BarStyle.SEGMENTED_10);
        for (Player p : world.getPlayers()) bar.addPlayer(p);
        bossBars.put(world.getUID(), bar);
        for (int i = 0; i < eventMobCount; i++) {
            Location spawn = eventLocation.clone().add(random.nextInt(9) - 4, 0, random.nextInt(9) - 4);
            spawn.setY(world.getHighestBlockYAt(spawn) + 1);
            EntityType mob = i == eventMobCount - 1 ? EntityType.ELDER_GUARDIAN : (i % 3 == 0 ? EntityType.HUSK : EntityType.ZOMBIE);
            Entity entity = world.spawnEntity(spawn, mob);
            entity.setCustomName(color("&dРазломный страж"));
            entity.setCustomNameVisible(true);
            entity.getPersistentDataContainer().set(new NamespacedKey(this, "event_mob"), PersistentDataType.BYTE, (byte) 1);
            if (entity instanceof LivingEntity living) {
                living.setRemoveWhenFarAway(false);
                if (living.getAttribute(Attribute.MAX_HEALTH) != null) {
                    double hp = mob == EntityType.ELDER_GUARDIAN ? 100 : 24;
                    living.getAttribute(Attribute.MAX_HEALTH).setBaseValue(hp);
                    living.setHealth(hp);
                }
            }
        }
        eventMobCount = eventLocation.getWorld().getNearbyEntities(eventLocation, 16, 12, 16).stream()
                .filter(ent -> ent.getPersistentDataContainer().has(new NamespacedKey(this, "event_mob"), PersistentDataType.BYTE)).toList().size();
    }

    private World chooseEventWorld(Player initiator) {
        if (initiator != null) return initiator.getWorld();
        List<String> names = getConfig().getStringList("settings.event-worlds");
        for (String name : names) {
            World w = Bukkit.getWorld(name);
            if (w != null) return w;
        }
        return Bukkit.getWorlds().isEmpty() ? null : Bukkit.getWorlds().get(0);
    }

    @EventHandler(ignoreCancelled = true)
    public void onEntityDeath(org.bukkit.event.entity.EntityDeathEvent e) {
        Entity entity = e.getEntity();
        NamespacedKey mobKey = new NamespacedKey(this, "event_mob");
        if (!entity.getPersistentDataContainer().has(mobKey, PersistentDataType.BYTE)) return;
        eventMobCount = Math.max(0, eventMobCount - 1);
        Player killer = entity.getKiller();
        if (killer != null) {
            PlayerProgress pp = progress.computeIfAbsent(killer.getUniqueId(), id -> new PlayerProgress());
            pp.xp += 10;
            pp.eventKills++;
            killer.sendMessage(color("&d+10 исследовательского опыта &7за победу над стражем."));
            if (random.nextDouble() < .2) {
                killer.getInventory().addItem(createItem("crystal_amethyst", 1)).values().forEach(item ->
                        killer.getWorld().dropItemNaturally(killer.getLocation(), item));
                killer.sendMessage(color("&5Ты получил Аметистовый кристалл!"));
            }
        }
        e.getDrops().clear();
        e.setDroppedExp(0);
    }

    private void updateBossBars() {
        if (eventLocation == null || eventLocation.getWorld() == null) return;
        BossBar bar = bossBars.get(eventLocation.getWorld().getUID());
        if (bar == null) return;
        double remaining = Math.max(0, eventEndsAt - System.currentTimeMillis());
        double total = getConfig().getLong("settings.event-duration-seconds", 300) * 1000.0;
        bar.setProgress(Math.min(1, Math.max(0, remaining / total)));
        for (Player p : eventLocation.getWorld().getPlayers()) if (!bar.getPlayers().contains(p)) bar.addPlayer(p);
    }

    private void endEvent() {
        if (!eventActive) return;
        if (eventLocation != null && eventLocation.getWorld() != null) {
            World w = eventLocation.getWorld();
            for (Entity e : w.getNearbyEntities(eventLocation, 40, 25, 40)) {
                if (e.getPersistentDataContainer().has(new NamespacedKey(this, "event_mob"), PersistentDataType.BYTE)) e.remove();
            }
            w.dropItemNaturally(eventLocation, createItem("crystal_void", 1));
            w.spawnParticle(Particle.FIREWORK, eventLocation, 50, 1, 1, 1, .1);
            w.playSound(eventLocation, Sound.UI_TOAST_CHALLENGE_COMPLETE, 1f, 1f);
            BossBar bar = bossBars.remove(w.getUID());
            if (bar != null) bar.removeAll();
        }
        eventActive = false;
        eventMobCount = 0;
        Bukkit.broadcastMessage(color("&dКристаллический разлом завершён! &fВ награду появился редкий кристалл."));
    }

    private ItemStack createItem(String id, int amount) {
        Material material = switch (id) {
            case "crystal_shard" -> Material.AMETHYST_SHARD;
            case "crystal_amethyst" -> Material.AMETHYST_CLUSTER;
            case "crystal_void" -> Material.ECHO_SHARD;
            case "artifact_storm" -> Material.PRISMARINE_CRYSTALS;
            default -> Material.AMETHYST_SHARD;
        };
        ItemStack item = new ItemStack(material, Math.max(1, Math.min(amount, material.getMaxStackSize())));
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            String display = switch (id) {
                case "crystal_shard" -> "&bКристаллический осколок";
                case "crystal_amethyst" -> "&5Аметистовый кристалл";
                case "crystal_void" -> "&dСердце разлома";
                case "artifact_storm" -> "&3Искра бури";
                default -> "&bКристалл";
            };
            meta.setDisplayName(color(display));
            meta.setLore(List.of(color("&7Предмет системы &bTmPixel Crystal Adventures"), color("&8ID: " + id)));
            meta.getPersistentDataContainer().set(itemKey, PersistentDataType.STRING, id);
            try { meta.setItemModel(new NamespacedKey("tmpixel", id)); } catch (Throwable ignored) {}
            item.setItemMeta(meta);
        }
        return item;
    }

    private void openMainMenu(Player p) {
        Inventory inv = Bukkit.createInventory(new MenuHolder("main"), 45, color("&8✦ &bTmPixel &dCrystal Adventures"));
        fill(inv, createDecor(Material.PURPLE_STAINED_GLASS_PANE, " "));
        inv.setItem(10, menuItem("crystal_shard", "&bКоллекция кристаллов", "&7Найдено: &f" + getProgress(p).crystalsFound, Material.AMETHYST_SHARD));
        inv.setItem(12, menuItem("artifact_storm", "&3Артефакты", "&7Открывай способности и бонусы", Material.PRISMARINE_CRYSTALS));
        inv.setItem(14, menuItem("event", "&dМировые события", eventActive ? "&aСобытие активно!" : "&7Ожидай следующий разлом", Material.END_CRYSTAL));
        inv.setItem(16, menuItem("stats", "&eМоя статистика", "&7Опыт: &f" + getProgress(p).xp + " &8| &7Убийств событий: &f" + getProgress(p).eventKills, Material.KNOWLEDGE_BOOK));
        inv.setItem(31, menuItem("close", "&cЗакрыть", "&7Вернуться в игру", Material.BARRIER));
        p.openInventory(inv);
        p.playSound(p.getLocation(), Sound.UI_BUTTON_CLICK, .6f, 1.2f);
    }

    private void openCollection(Player p) {
        Inventory inv = Bukkit.createInventory(new MenuHolder("collection"), 54, color("&8Коллекция кристаллов"));
        fill(inv, createDecor(Material.BLACK_STAINED_GLASS_PANE, " "));
        inv.setItem(10, createItem("crystal_shard", 1));
        inv.setItem(12, createItem("crystal_amethyst", 1));
        inv.setItem(14, createItem("crystal_void", 1));
        inv.setItem(49, menuItem("back", "&e← Назад", "&7В главное меню", Material.ARROW));
        p.openInventory(inv);
    }

    private ItemStack menuItem(String id, String name, String lore, Material mat) {
        ItemStack it = new ItemStack(mat);
        ItemMeta meta = it.getItemMeta();
        meta.setDisplayName(color(name));
        meta.setLore(List.of(color(lore), color("&8TmPixel Crystal Adventures")));
        meta.getPersistentDataContainer().set(itemKey, PersistentDataType.STRING, id);
        try { meta.setItemModel(new NamespacedKey("tmpixel", id)); } catch (Throwable ignored) {}
        it.setItemMeta(meta);
        return it;
    }

    private ItemStack createDecor(Material mat, String name) {
        ItemStack it = new ItemStack(mat);
        ItemMeta meta = it.getItemMeta();
        meta.setDisplayName(color(name));
        it.setItemMeta(meta);
        return it;
    }

    private void fill(Inventory inv, ItemStack item) {
        for (int i = 0; i < inv.getSize(); i++) inv.setItem(i, item.clone());
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent e) {
        if (!(e.getView().getTopInventory().getHolder(false) instanceof MenuHolder holder)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (e.getClickedInventory() == null || e.getClickedInventory() != e.getView().getTopInventory()) return;
        ItemStack clicked = e.getCurrentItem();
        if (clicked == null || !clicked.hasItemMeta()) return;
        String id = clicked.getItemMeta().getPersistentDataContainer().get(itemKey, PersistentDataType.STRING);
        if (id == null) return;
        switch (id) {
            case "crystal_shard" -> openCollection(p);
            case "back" -> openMainMenu(p);
            case "close" -> p.closeInventory();
            case "event" -> {
                p.closeInventory();
                p.sendMessage(color(eventActive
                        ? "&dРазлом активен на координатах: &f" + (eventLocation == null ? "?" : eventLocation.getBlockX() + ", " + eventLocation.getBlockY() + ", " + eventLocation.getBlockZ())
                        : "&7Сейчас активного события нет. Следи за объявлениями!"));
            }
            case "stats" -> {
                PlayerProgress pp = getProgress(p);
                p.sendMessage(color("&bТвоя статистика: &fXP " + pp.xp + " &7| Кристаллы: &f" + pp.crystalsFound + " &7| Победы: &f" + pp.eventKills));
                p.closeInventory();
            }
            case "artifact_storm" -> p.sendMessage(color("&3Артефакты: &7система артефактов будет расширяться через будущие версии."));
        }
    }

    @EventHandler
    public void onInventoryDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder(false) instanceof MenuHolder) e.setCancelled(true);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            if (sender instanceof Player p) openMainMenu(p);
            else sender.sendMessage("TmPixel Crystal Adventures commands: /tca event status|start|stop, /tca give, /tca pack");
            return true;
        }
        if (args[0].equalsIgnoreCase("pack")) {
            if (args.length > 1 && args[1].equalsIgnoreCase("verify")) {
                sender.sendMessage(color("&7Pack SHA-1: &f" + packHash()));
                return true;
            }
            sender.sendMessage(color("&bResource pack: &f" + (getConfig().getString("pack.public-url", "").isBlank() ? "URL не настроен" : "URL настроен")));
            sender.sendMessage(color("&7Встроенный ZIP: plugins/TmPixelCrystalAdventures/resourcepack.zip"));
            return true;
        }
        if (args[0].equalsIgnoreCase("event")) {
            if (!sender.hasPermission("tca.admin")) { sender.sendMessage(color("&cНет прав.")); return true; }
            if (args.length > 1 && args[1].equalsIgnoreCase("start")) {
                startEvent(sender instanceof Player p ? p : null);
                return true;
            }
            if (args.length > 1 && args[1].equalsIgnoreCase("stop")) {
                endEvent();
                return true;
            }
            sender.sendMessage(color(eventActive ? "&dСобытие активно." : "&7Событие не активно."));
            return true;
        }
        if (args[0].equalsIgnoreCase("give")) {
            if (!sender.hasPermission("tca.admin")) { sender.sendMessage(color("&cНет прав.")); return true; }
            if (args.length < 3) { sender.sendMessage("/tca give <player> <crystal_shard|crystal_amethyst|crystal_void|artifact_storm>"); return true; }
            Player target = Bukkit.getPlayerExact(args[1]);
            if (target == null) { sender.sendMessage(color("&cИгрок не найден или не в сети.")); return true; }
            target.getInventory().addItem(createItem(args[2].toLowerCase(Locale.ROOT), 1));
            sender.sendMessage(color("&aПредмет выдан игроку " + target.getName()));
            return true;
        }
        if (args[0].equalsIgnoreCase("reload")) {
            if (!sender.hasPermission("tca.admin")) { sender.sendMessage(color("&cНет прав.")); return true; }
            reloadConfig();
            sender.sendMessage(color("&aКонфигурация перезагружена."));
            return true;
        }
        sender.sendMessage(color("&7Команды: /tca, /tca event status|start|stop, /tca give, /tca pack status|verify, /tca reload"));
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) return List.of("event", "give", "pack", "reload");
        if (args.length == 2 && args[0].equalsIgnoreCase("event")) return List.of("status", "start", "stop");
        if (args.length == 2 && args[0].equalsIgnoreCase("pack")) return List.of("status", "info", "verify");
        if (args.length == 2 && args[0].equalsIgnoreCase("give")) return Bukkit.getOnlinePlayers().stream().map(Player::getName).toList();
        if (args.length == 3 && args[0].equalsIgnoreCase("give")) return List.of("crystal_shard", "crystal_amethyst", "crystal_void", "artifact_storm");
        return Collections.emptyList();
    }

    private PlayerProgress getProgress(Player p) { return progress.computeIfAbsent(p.getUniqueId(), id -> new PlayerProgress()); }

    private void loadProgress() {
        File file = new File(getDataFolder(), "players.yml");
        if (!file.exists()) return;
        org.bukkit.configuration.file.YamlConfiguration data = org.bukkit.configuration.file.YamlConfiguration.loadConfiguration(file);
        for (String key : data.getKeys(false)) {
            try {
                UUID id = UUID.fromString(key);
                PlayerProgress pp = new PlayerProgress();
                pp.xp = data.getInt(key + ".xp");
                pp.crystalsFound = data.getInt(key + ".crystalsFound");
                pp.eventKills = data.getInt(key + ".eventKills");
                progress.put(id, pp);
            } catch (Exception ex) { getLogger().warning("Skipped invalid player record: " + key); }
        }
    }

    private synchronized void saveProgressSafely() {
        try {
            if (!getDataFolder().exists()) getDataFolder().mkdirs();
            org.bukkit.configuration.file.YamlConfiguration data = new org.bukkit.configuration.file.YamlConfiguration();
            for (Map.Entry<UUID, PlayerProgress> entry : progress.entrySet()) {
                String key = entry.getKey().toString();
                data.set(key + ".xp", entry.getValue().xp);
                data.set(key + ".crystalsFound", entry.getValue().crystalsFound);
                data.set(key + ".eventKills", entry.getValue().eventKills);
            }
            data.save(new File(getDataFolder(), "players.yml"));
        } catch (Exception ex) {
            getLogger().severe("Could not save player data: " + ex.getMessage());
        }
    }

    private String color(String s) { return ChatColor.translateAlternateColorCodes('&', s == null ? "" : s); }

    private static final class PlayerProgress {
        int xp = 0;
        int crystalsFound = 0;
        int eventKills = 0;
    }

    private static final class MenuHolder implements InventoryHolder {
        private final String id;
        private MenuHolder(String id) { this.id = id; }
        @Override public Inventory getInventory() { return null; }
        public String id() { return id; }
    }
}
